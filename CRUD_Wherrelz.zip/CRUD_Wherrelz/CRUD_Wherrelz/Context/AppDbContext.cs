﻿using CRUD_Wherrelz.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Text.Json;

namespace CRUD_Wherrelz.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Entries> Entries { get; set; }
        public DbSet<Audit> Audits { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasIndex(u => u.LoginId).IsUnique();
        }

        //public string? CurrentUser_LoginId { get; set; }

        //public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        //{
        //    var Audits = new List<Audit>();

        //    foreach (var entry in ChangeTracker.Entries().Where(e => e.State == EntityState.Modified || e.State == EntityState.Added || e.State == EntityState.Deleted))
        //    {
        //        var entityName = entry.Entity.GetType().Name;
        //        var keyProp = entry.Properties.FirstOrDefault(p => p.Metadata.IsPrimaryKey());
        //        int? keyValue = null;
        //        if (keyProp?.CurrentValue != null && int.TryParse(keyProp.CurrentValue.ToString(), out var kv))
        //            keyValue = kv;

        //        if (entry.State == EntityState.Added)
        //        {
        //            foreach (var prop in entry.Properties)
        //            {
        //                Audit.Add(new Audit
        //                {
        //                    Table_Name = entityName,
        //                    Field_Name = prop.Metadata.Name,
        //                    Old_Value = null,
        //                    New_Value = prop.CurrentValue?.ToString(),
        //                    Key_Value = keyValue,
        //                    Changed_At = DateTime.UtcNow,
        //                    Changed_By = CurrentUser_LoginId
        //                });
        //            }
        //        }

        //        else if (entry.State == EntityState.Deleted)
        //        {
        //            foreach (var prop in entry.Properties)
        //            {
        //                Audits.Add(new Audit
        //                {
        //                    Table_Name = entityName,
        //                    Field_Name = prop.Metadata.Name,
        //                    Old_Value = prop.OriginalValue?.ToString(),
        //                    New_Value = null,
        //                    Key_Value = keyValue,
        //                    Changed_At = DateTime.UtcNow,
        //                    Changed_By = CurrentUser_LoginId
        //                });
        //            }
        //        }
        //        else if (entry.State == EntityState.Modified)
        //        {
        //            foreach (var prop in entry.Properties)
        //            {
        //                if (prop.IsModified)
        //                {
        //                    Audit.Add(new Audit
        //                    {
        //                        Table_Name = entityName,
        //                        Field_Name = prop.Metadata.Name,
        //                        Old_Value = prop.OriginalValue?.ToString(),
        //                        New_Value = null,
        //                        Key_Value = keyValue,
        //                        Changed_At = DateTime.UtcNow,
        //                        Changed_By = CurrentUser_LoginId
        //                    });
        //                }
        //            }
        //        }
        //    }
        //    if (Audit.Any())
        //    {
        //        Audits.AddRange(Audit);
        //    }
        //    return await base.SaveChangesAsync(cancellationToken);
        //}

    }
}
