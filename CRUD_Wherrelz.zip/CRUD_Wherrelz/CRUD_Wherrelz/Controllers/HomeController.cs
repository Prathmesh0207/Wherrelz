using CRUD_Wherrelz.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize]
public class HomeController : Controller
{
    private readonly AppDbContext _context;
    public HomeController(AppDbContext context) => _context = context;

    public async Task<IActionResult> Dashboard()
    {
        var totalCredit = _context.Entries.Sum(e => e.Credit);
        var totalDebit = _context.Entries.Sum(e => e.Debit);
        var entriesCount = _context.Entries.Count();
        //var recentEntries = await _context.Entries.ToListAsync();
        var entry = await _context.Entries.ToListAsync();
        var isActive = entry.Where(item => item.IsActive).ToList();


        ViewBag.TotalCredit = totalCredit;
        ViewBag.TotalDebit = totalDebit;
        ViewBag.EntriesCount = entriesCount;
        ViewBag.RecentEntries = isActive;

        return View();
    }
}
