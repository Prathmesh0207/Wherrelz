﻿using CRUD_Wherrelz.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize]
public class AuditController : Controller
{
    private readonly AppDbContext _context;
    public AuditController(AppDbContext context) => _context = context;

    public async Task<IActionResult> Index()
    {
        var listedAudit = await _context.Audits.OrderByDescending(a => a.ChangedAt).ToListAsync();
        return View(listedAudit);
    }
}
