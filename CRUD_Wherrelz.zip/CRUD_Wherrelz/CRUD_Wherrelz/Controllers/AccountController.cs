﻿using CRUD_Wherrelz.Context;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

[Authorize]
public class AccountController : Controller
{
    private readonly AppDbContext _context;
    public AccountController(AppDbContext context)
    {
        _context = context;
    }

    [AllowAnonymous]
    [HttpGet]
    public  IActionResult Login() => View();


    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> Login(string loginId, string password)
    {
        //var huijkl = BCrypt.Net.BCrypt.HashPassword("admin123");
        var user = await _context.Users.FirstOrDefaultAsync(u => u.LoginId == loginId && u.IsActive);
        if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.Password))
        {
            ViewBag.Error = "Invalid login";
            return View();
        }

        var claims = new List<Claim> { new Claim(ClaimTypes.Name, user.LoginId) };
        var identity = new ClaimsIdentity(claims, "MyCookieAuth");
        var principal = new ClaimsPrincipal(identity);
        await HttpContext.SignInAsync("MyCookieAuth", new ClaimsPrincipal(identity));

        await HttpContext.SignInAsync("MyCookieAuth", principal, new AuthenticationProperties
        {
            IsPersistent = true,
            ExpiresUtc = DateTimeOffset.UtcNow.AddHours(1)
        });
        return RedirectToAction("Dashboard", "Home");
    }

    [AllowAnonymous]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync("MyCookieAuth");
        if (HttpContext?.Session != null && HttpContext.Session.IsAvailable)
        {
            var keys = HttpContext.Session.Keys.ToList();
            foreach (var key in keys)
                HttpContext.Session.Remove(key);
        }
        return RedirectToAction("Login");
    }
}
