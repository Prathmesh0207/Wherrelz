﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRUD_Wherrelz.Models
{
    public class Entries
    {
        public int Id { get; set; }
        [Required, MaxLength(100)]
        public string Account { get; set; }
        [MaxLength(255)]
        public string Narration { get; set; }
        [Required, MaxLength(3)]
        public string Currency { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal Credit { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal Debit { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public bool IsActive { get; set; } = true;
    }
}
