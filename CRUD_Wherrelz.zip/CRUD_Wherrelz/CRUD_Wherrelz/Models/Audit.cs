﻿using System.ComponentModel.DataAnnotations;

namespace CRUD_Wherrelz.Models
{
    public class Audit
    {
        public int Id { get; set; }
        [Required, MaxLength(50)]
        public string Table { get; set; }
        [Required, MaxLength(50)]
        public string Field { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public DateTime ChangedAt { get; set; } = DateTime.Now;
        [MaxLength(50)]
        public string ChangedBy { get; set; }

    }
}
