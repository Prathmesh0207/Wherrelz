﻿using System.ComponentModel.DataAnnotations;

namespace CRUD_Wherrelz.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required, MaxLength(50)]
        public string LoginId { get; set; }

        [Required, MaxLength(255)]
        public string Password { get; set; }

        public bool IsActive { get; set; } = true;

    }
}
