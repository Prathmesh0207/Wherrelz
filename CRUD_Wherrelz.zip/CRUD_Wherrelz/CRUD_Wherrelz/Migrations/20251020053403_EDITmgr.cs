﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRUD_Wherrelz.Migrations
{
    /// <inheritdoc />
    public partial class EDITmgr : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "Entries",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "Entries");
        }
    }
}
