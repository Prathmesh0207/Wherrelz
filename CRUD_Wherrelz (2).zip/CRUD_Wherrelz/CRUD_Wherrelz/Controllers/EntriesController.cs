﻿using CRUD_Wherrelz.Context;
using CRUD_Wherrelz.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

[Authorize]
public class EntriesController : Controller
{
    private readonly AppDbContext _context;
    public EntriesController(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {

        var entry = await _context.Entries.ToListAsync();
        return View(entry);

    }

    public IActionResult Create() => View();
    [HttpPost]
    public async Task<IActionResult> Create(Entries entry)
    {
        if (ModelState.IsValid)
        {
            _context.Add(entry);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        return View(entry);
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var entry = await _context.Entries.FindAsync(id);
        if (entry == null)
            return NotFound();
        return View(entry);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, Entries updatedEntry)
    {
        var entry = await _context.Entries.FindAsync(id);
        if (entry == null) return NotFound();

       
         if (entry.Account != updatedEntry.Account)
            _context.Audits.Add(new Audit
            {
                Table = "Entries",
                Field = "Account",
                OldValue = entry.Account.ToString(),
                NewValue = updatedEntry.Account.ToString(),
                ChangedBy = User.Identity.Name
            });
        else if (entry.Narration != updatedEntry.Narration)
            _context.Audits.Add(new Audit
            {
                Table = "Entries",
                Field = "Narration",
                OldValue = entry.Narration.ToString(),
                NewValue = updatedEntry.Narration.ToString(),
                ChangedBy = User.Identity.Name
            });
        else if (entry.Currency != updatedEntry.Currency)
            _context.Audits.Add(new Audit
            {
                Table = "Entries",
                Field = "Currency",
                OldValue = entry.Currency.ToString(),
                NewValue = updatedEntry.Currency.ToString(),
                ChangedBy = User.Identity.Name
            });

        else if (entry.Credit != updatedEntry.Credit)
            _context.Audits.Add(new Audit
            {
                Table = "Entries",
                Field = "Credit",
                OldValue = entry.Credit.ToString(),
                NewValue = updatedEntry.Credit.ToString(),
                ChangedBy = User.Identity.Name
            });

        else if (entry.Debit != updatedEntry.Debit)
            _context.Audits.Add(new Audit
            {
                Table = "Entries",
                Field = "Debit",
                OldValue = entry.Debit.ToString(),
                NewValue = updatedEntry.Debit.ToString(),
                ChangedBy = User.Identity.Name
            });
        entry.Account = updatedEntry.Account;
        entry.Narration = updatedEntry.Narration;
        entry.Currency = updatedEntry.Currency;
        entry.Credit = updatedEntry.Credit;
        entry.Debit = updatedEntry.Debit;




        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
    }


    public async Task<IActionResult> Delete(int id)
    {

        var entry = await _context.Entries.FindAsync(id);
        if (entry == null)
            return NotFound();
        return View(entry);
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var Entry = await _context.Entries.FindAsync(id);
        if (Entry != null)
        {
            _context.Entries.Remove(Entry);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

}
