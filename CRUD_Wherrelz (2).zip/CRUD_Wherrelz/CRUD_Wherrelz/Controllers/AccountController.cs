﻿using CRUD_Wherrelz.Context;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

[Authorize]
public class AccountController : Controller
{
    private readonly AppDbContext _context;
    public AccountController(AppDbContext context)
    {
        _context = context;
    }

    [AllowAnonymous]
    [HttpGet]
    public  IActionResult Login() => View();


    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> Login(string loginId, string password)
    {
        var huijkl = BCrypt.Net.BCrypt.HashPassword("Admin@123");
        var user = await _context.Users.FirstOrDefaultAsync(u => u.LoginId == loginId && u.IsActive);
        if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.Password))
        {
            ViewBag.Error = "Invalid login";
            return View();
        }

        var claims = new List<Claim> { new Claim(ClaimTypes.Name, user.LoginId) };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var principal = new ClaimsPrincipal(identity);
         await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties
        {
            IsPersistent = true,
            ExpiresUtc = DateTimeOffset.UtcNow.AddHours(1)
        });
        return RedirectToAction("Dashboard", "Home");
    }

    [AllowAnonymous]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme); // your cookie scheme name
        HttpContext.Session.Clear(); // optional
        return RedirectToAction("Login", "Account");
    }
    
    public IActionResult AccessDenied() => View();
}
