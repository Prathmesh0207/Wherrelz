﻿using CRUD_Wherrelz.Context;
using CRUD_Wherrelz.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Update;

[Authorize]
public class UsersController : Controller
{
    private readonly AppDbContext _context;
    public UsersController(AppDbContext context) => _context = context;

    public async Task<IActionResult> Index()
    {
        var user = await _context.Users.ToListAsync();
        var isActive = user.Where(item => item.IsActive).ToList();
        return View(isActive);
    }

    public IActionResult Create() => View();
    [HttpPost]
    public async Task<IActionResult> Create(User user)
    {
        var isExist = await _context.Users.AnyAsync(u => u.LoginId == user.LoginId);
        if (isExist)
        {
            ViewBag.UserExist = "Username already exists!";
            return View(user);

        }
       if(ModelState.IsValid)
        {
            // Hash the password
            user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);

            _context.Add(user);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
            return View(user);
    }

    public async Task<IActionResult> Edit(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null) return NotFound();
        return View(user);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, User updatedUser)
    {
        if (id != updatedUser.Id) return NotFound();

        var user = await _context.Users.FindAsync(id);
        if (user == null) return NotFound();

        if (ModelState.IsValid)
        {
            if (user.LoginId != updatedUser.LoginId)
                _context.Audits.Add(new Audit
                {
                    Table = "User",
                    Field = "LoginId",
                    OldValue = user.LoginId.ToString(),
                    NewValue = updatedUser.LoginId.ToString(),
                    ChangedBy = User.Identity.Name
                });
            if (user.IsActive != updatedUser.IsActive)
                _context.Audits.Add(new Audit
                {
                    Table = "User",
                    Field = "IsActive",
                    OldValue = user.IsActive.ToString(),
                    NewValue = updatedUser.IsActive.ToString(),
                    ChangedBy = User.Identity.Name
                });
            user.LoginId = updatedUser.LoginId;
            user.IsActive = updatedUser.IsActive;




            // Check if password changed
            if (!BCrypt.Net.BCrypt.Verify(updatedUser.Password, user.Password))
            {
                user.Password = BCrypt.Net.BCrypt.HashPassword(updatedUser.Password);
            }

            _context.Update(user);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        return View(updatedUser);
    }

    public async Task<IActionResult> Delete(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user != null) { user.IsActive = false; await _context.SaveChangesAsync(); }
        return RedirectToAction("Index");
    }
}
