﻿// Select DOM elements
var body = document.querySelector("body");
var modal = document.querySelector(".modal");
var modalButton = document.querySelector(".modal-button");
var closeButton = document.querySelector(".close-button");
var scrollDown = document.querySelector(".scroll-down");
var form = document.querySelector("#loginForm");
var isOpened = false;

// Open modal
function openModal() {
    modal.classList.add("is-open");
    body.style.overflow = "hidden";
}

// Close modal
function closeModal() {
    modal.classList.remove("is-open");
    body.style.overflow = "initial";
}

// Show modal after scroll
window.addEventListener("scroll", function () {
    if (window.scrollY > window.innerHeight / 3 && !isOpened) {
        isOpened = true;
        if (scrollDown) scrollDown.style.display = "none";
        openModal();
    }
});

// If modalButton exists, add listener (optional fallback)
if (modalButton) modalButton.addEventListener("click", openModal);

// Close modal on button
if (closeButton) closeButton.addEventListener("click", closeModal);

// ESC key closes modal
document.onkeydown = function (evt) {
    evt = evt || window.event;
    if (evt.keyCode === 27) {
        closeModal();
    }
};

// ✅ Empty field validation before submit
form.addEventListener("submit", function (e) {
    var loginId = document.getElementById("LoginId").value.trim();
    var password = document.getElementById("Password").value.trim();
    var valid = true;

    // Reset old validation messages
    document.querySelectorAll(".text-danger").forEach(function (el) {
        el.innerText = "";
    });

    // Validate login
    if (loginId === "") {
        document.querySelector("span[asp-validation-for='LoginId']").innerText = "Username is required.";
        valid = false;
    }

    // Validate password
    if (password === "") {
        document.querySelector("span[asp-validation-for='Password']").innerText = "Password is required.";
        valid = false;
    }

    // Prevent submit if invalid
    if (!valid) {
        e.preventDefault();
    }
});
